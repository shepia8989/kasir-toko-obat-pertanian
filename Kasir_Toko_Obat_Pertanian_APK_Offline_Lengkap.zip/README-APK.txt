PROYEK APK ANDROID — KASIR TOKO OBAT PERTANIAN

PENTING
- Ini adalah proyek sumber Android yang disiapkan untuk dibangun menjadi APK.
- APK belum dikompilasi di sini. Proses build memakai GitHub Actions (layanan cloud).
- Aplikasi menyimpan data di penyimpanan lokal WebView pada HP. Aplikasi dirancang offline dan tidak meminta izin internet; data disimpan secara lokal di HP. Tidak ada sinkronisasi cloud.
- Pencetakan struk Bluetooth bergantung pada printer dan aplikasi/layanan cetak Android; fungsi cetak perlu diuji di perangkat sasaran.
- Harga contoh adalah data dummy. Ubah melalui menu Barang sebelum dipakai.

CARA MEMBANGUN APK HANYA DENGAN HP ANDROID
1. Unduh ZIP proyek ini dan ekstrak dengan aplikasi pengelola berkas.
2. Buat akun atau masuk ke GitHub melalui browser.
3. Buat repository baru, misalnya: kasir-toko-obat-pertanian.
4. Unggah seluruh isi folder proyek yang diekstrak ke repository (termasuk folder .github/workflows/build-apk.yml). Jangan hanya mengunggah ZIP proyek sebagai satu file.
5. Buka tab Actions di repository dan aktifkan Actions jika diminta.
6. Pilih workflow "Build Android APK", lalu tekan Run workflow.
7. Setelah proses selesai dengan status hijau, buka run tersebut dan unduh artifact bernama kasir-toko-obat-pertanian-debug-apk.
8. Ekstrak artifact ZIP hasil build untuk menemukan app-debug.apk. Buka APK di HP dan izinkan instalasi dari sumber tersebut jika Android memintanya.

CATATAN TEKNIS
- package id: id.tokobatpertanian.kasir
- Minimum Android: Android 6.0 (API 23)
- APK debug cocok untuk uji coba pribadi, bukan distribusi produksi.
- Jangan mengunggah data pelanggan nyata atau informasi sensitif ke repository publik.
