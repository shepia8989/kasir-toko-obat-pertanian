TOKO OBAT PERTANIAN — PROTOTIPE KASIR

Isi:
- www/index.html: aplikasi kasir yang berjalan di browser modern.
- www/manifest.json dan www/sw.js: dukungan instalasi/offline sebagai web app bila disajikan melalui HTTPS.

Cara mencoba:
1. Ekstrak ZIP.
2. Buka www/index.html di browser jika perangkat mengizinkan pembukaan file lokal.
3. Untuk pengalaman offline/PWA yang stabil, file perlu dihosting melalui HTTPS lalu buka situsnya di Chrome Android dan pilih "Tambahkan ke layar utama".

Fitur saat ini:
- Data produk, stok, keranjang, pembayaran dan kembalian.
- Transaksi dan estimasi laba kotor.
- Riwayat transaksi.
- Cetak struk melalui dialog print browser; kompatibilitas Bluetooth tergantung browser/printer.
- Ekspor dan impor cadangan JSON.
- Penyimpanan lokal browser.

PENTING:
Ini adalah prototipe web yang dapat diuji, BUKAN APK Android yang sudah dikompilasi.
Sinkronisasi online/server belum dibuat. Data saat ini tersimpan di browser pada perangkat ini; hapus data browser dapat menghilangkannya. Unduh cadangan secara berkala.
Untuk membuat APK native, proyek ini perlu dibungkus dengan Android WebView/Capacitor dan dibangun menggunakan Android SDK atau layanan build yang tepercaya.
Harga contoh adalah data dummy; ubah sesuai harga toko.
